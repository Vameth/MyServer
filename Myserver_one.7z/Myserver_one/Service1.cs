﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Myserver_one
{
    public partial class Service1 : ServiceBase
    {
        public Service1()
        {
            InitializeComponent();
        }

        protected override async void OnStart(string[] args)
        {
            //делаем случайное число 
           
                File.AppendAllText(@"C:\Users\VasilevAO02\Desktop\1.txt",
                    "Служба запущена");
            await Task.Delay(300);
        }
    }
}
